# smartWatch
This is a smart watch which has time, music and message applications.

## Technology used
HTML, CSS, JavaScript, JQuery.

## Objective
Create a smartwatch application

## Guidelines

1. when you open the app, homescreen of the watch will appear.

2. You can find menu button,clicking on that, three icons(message, music, timer) will appear on the screen

3. when you click message icon, it will enter into message app.

4. To come back, double tap on message icon which is on top of the message app. 

5. when you click music icon, it will enter into music app where you can play music.

6. To come back, double tap on music icon which is on top of the music app. 

7. when you click timer icon, it will enter into timer app where you can calculte time duration.

8. To come back, double tap on timer icon which is on top of the timer app.

## Link
https://smart-watch-54e03c.netlify.com/





